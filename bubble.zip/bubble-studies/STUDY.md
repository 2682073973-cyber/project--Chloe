# Bubble Studies

Three small, phone-sized interaction studies about a soap bubble's life: the wand is loaded and shaken, a bubble is blown and lifted away, and a bubble cracks and dissolves. Each is a single self-contained HTML file (inline CSS + vanilla JS, no framework, no build step). Each runs on its own and each has a clear start state, two user steps, and an end state, so they can be chained into one sequential prototype.

| # | Study | Folder | Steps | Rendering |
|---|-------|--------|-------|-----------|
| 01 | Slime Wand | `01-slime-wand/index.html` | Hold → Shake | `<canvas>` 2D, physics loop |
| 02 | Bubble Release | `02-bubble-release/index.html` | Release → Lift | DOM + CSS transitions, state machine |
| 03 | Fragile Bubble | `03-fragile-bubble/index.html` | Crack → Release | SVG + Web Animations API |

## Running

Open `index.html` (launcher) or any study's `index.html` directly in a modern browser. A local server is optional but recommended (fonts and pointer capture behave most consistently):

```bash
npm start            # = npx serve -l 5173 .
# or: python3 -m http.server 5173
```

**Dependencies:** none to install. The only external resources are Google Fonts stylesheets (Fraunces + IBM Plex Mono; Figtree; Fragment Mono + Instrument Sans). Offline, each study falls back to system fonts with no change in behavior. No images or other asset files are used — everything is drawn in code.

**Browser features used:** Pointer Events + `setPointerCapture`, Canvas 2D, Web Animations API (`element.animate`), CSS custom properties, `prefers-color-scheme`, `prefers-reduced-motion`.

---

## 01 · Slime Wand

**What it does.** A bubble wand dipped in slime. Press and hold the wand to grip it, then drag left/right to shake it; the slime membrane lags, ripples and drips with spring physics. A wobble meter reports how agitated the film is.

**Visual components**
- Header: title + two-step pill rail (`1 Hold`, `2 Shake`) — `#s1`, `#s2`.
- Stage: one full-size `<canvas id="c">` drawing the wand (ring, handle, grip), the translucent slime film with a gloss highlight, a drip below the ring, a floor shadow, and phase cues.
- Status line: instruction text `#msg` (aria-live) + `#wob` wobble readout. `Reset` button.
- Light/dark palettes via CSS variables, read into the canvas each frame by `col()`.

**User actions, feedback, states, transitions** (`S.phase`)

| State | Cue on canvas | Enter by | Leave by |
|-------|---------------|----------|----------|
| `idle` | Dashed pulsing ring on handle, "PRESS & HOLD" | load, release pointer, Reset | pointerdown on wand → `holding` |
| `holding` | Ring fills over 0.6 s, "HOLDING", wand begins to light | pointerdown hitting wand (`hit()`) | ring full → `armed`; pointerup → `idle` |
| `armed` | Chevrons ‹ › either side, "DRAG ← →", wand fully lit | hold completes | first direction change while dragging (> 120 px/s) → `shaking` |
| `shaking` | Speed trails, "SHAKE nn" counter | shake detected | pointerup / cancel / lost capture → `idle` (wand springs back to centre) |

Continuous feedback in every state: wand tilts with velocity; film offset spring (`ox/oy`), 28-point rim ripple ring (`S.r`), drip spring (`S.drip`); wobble meter smooths their energy. Reduced motion freezes the cue pulse.

**Where in the code** (single `<script>` IIFE)
- State object `S`, `geom()` layout, `hit()` hit-test, `setPhase()` (updates pills + message).
- Input: `pointerdown` / `pointermove` / `up()` listeners on the canvas; Reset handler.
- `step(now)` — rAF loop: hold timer → arm, wand easing, shake detection, all spring physics, wobble meter.
- `draw(g)` — cues block (`// ===== CUES =====`), then wand + film + drip (`// ===== WAND =====`).

**End state for chaining:** `shaking` with a shake count; there is no terminal state — releasing returns to `idle`. A sequence can treat "N shakes" (e.g. `S.shakes >= 4`) as completion.

---

## 02 · Bubble Release

**What it does.** Press and hold the wand to grow a bubble out of its loop; let go and the bubble springs up to a resting point and gently breathes. Swipe it upward past a dashed threshold and it drifts off the top of the screen.

**Origin.** Built as a Claude Design canvas artboard (390×844, "Release → Lift"). The original files are kept verbatim in `02-bubble-release/source/` (`Main.dc.html`, `canvas.json`); they require the Design canvas runtime and are included for reference. `02-bubble-release/index.html` is a standalone port: identical markup, styles and `Component` logic (`startPress`, `endPress`, `floatUp`, `reset`, `renderVals`), with a small `render()` binding that writes `renderVals()` into the DOM in place of the canvas runtime. The fixed frame is scaled down to fit short viewports.

**Visual components**
- Step rail (`Release`, `Lift` bars + labels) and a round Reset icon button.
- Wand button `#wand` (SVG loop with soap film + handle), pulsing press-cue rings `#pressCue`.
- Bubble button `#bubble` (radial-gradient skin, highlight arcs, `breathe` animation at rest).
- Swipe-up chevrons `#swipeCue`, dashed threshold line `#threshold`.
- Caption ("Step 1 of 2" / "Step 2 of 2" / "Complete") and instruction label, aria-live.

**User actions, feedback, states, transitions** (`state.phase`)

| State | Feedback | Enter by | Leave by |
|-------|----------|----------|----------|
| `idle` | Film in wand loop, pulsing rings, "Hold the wand, then let go" | load / Reset | pointerdown or Space/Enter down on wand → `pressing` |
| `pressing` | Wand tilts −5°, bubble grows 36→120 px over 1.4 s, label switches to "Let go to release" at 35 % | press | pointerup/cancel or key up → `released` (min size 45 %) |
| `released` | Bubble springs to y=400 (overshoot curve), breathes; chevrons bob; step 2 active | release | pointerdown on bubble → `dragging`; ArrowUp/Enter/Space → `floating` |
| `dragging` | Bubble follows finger with resistance and stretches vertically; threshold line darkens and label says "Let go to lift" once 70 px up | drag | release past threshold → `floating`; otherwise → `released` |
| `floating` | 5.6 s drift up and right, fades to 0.7; "Floating up…" | lift | timer 5.8 s → `done` |
| `done` | "Drifted away. Reset to begin again." | timer | Reset → `idle` |

**Where in the code** (`02-bubble-release/index.html`)
- `class Component` — state machine and all values (`renderVals()` holds every position, size, transition curve, cue visibility and copy).
- Binding IIFE — `render()` applies values to elements; event listeners map to the `renderVals()` handlers (`wandDown/Up`, `wandKeyDown/Up`, `bubbleDown/Move/Up`, `bubbleKey`, `reset`); `fitFrame()` scaling.
- Keyframes `pulse`, `bob`, `breathe` in the `<style>` block.

**End state for chaining:** `done` (or `floating`) — the bubble has left the frame.

---

## 03 · Fragile Bubble

**What it does.** A floating bubble that breaks on contact. Tap it and cracks race outward from the touch point before it splits into seven shards that tremble in place. Tap any shard and all the pieces fall and dissolve outward from that touch, with dust specks.

**Visual components**
- Header label "Fragile · 2 taps" and a Reset pill (fills solid when the run is over).
- Stage: one SVG (`#s`, 300×300 viewBox) inside a gently floating wrapper — groups `#cue` (dashed pulse rings), `#whole` (intact bubble), `#cracks` (clipped crack strokes), `#frags` (shard groups, each clipped by its own polygon), `#fx` (ripples + dust).
- Footer: cue headline with a blinking dot + sub-line (aria-live), and a two-step track (`01 Crack`, `02 Release`) with animated bars.
- Light/dark palettes; reduced-motion shortens all timings and removes looping animation.

**User actions, feedback, states, transitions** (`state`)

| State | Feedback | Enter by | Leave by |
|-------|----------|----------|----------|
| `intact` | Pulsing rings, bubble squashes while pressed, "Tap the bubble." | load / Reset | pointerup on bubble or Enter/Space → `cracking`; tap elsewhere → ripple + hint |
| `cracking` | Impact ripple, crack lines draw from the touch point with small branches, stage shake (~0.5 s) | tap | auto → `cracked` |
| `cracked` | Seven shards pop apart and tremble, edges pulse, "Tap a fragment." | split done | pointerup on a shard or Enter/Space → `releasing`; tap empty space → ripple, shards blink, hint |
| `releasing` | Big ripple, tapped shard's edge flashes, shards fall and blur out staggered by distance, dust | shard tap | auto (~1.6 s) → `gone` |
| `gone` | Empty stage, "Nothing left.", Reset highlighted | release done | Reset → `intact` (bubble pops back in) |

**Where in the code** (single `<script>` IIFE in `03-fragile-bubble/index.html`)
- Helpers: `el()`, `later()`, `dur()`, `T()` transform builder, `bubbleParts()`, `setCue()`, `setTrack()`, `toLocal()`, `ripple()`.
- `makeShards()` — crack ray + shard polygon geometry from the impact point.
- State functions: `reset()`, `crack()`, `split()`, `tremble()`, `release()`, `dust()`, `done()`, `nudge()`.
- Input: `pointerdown` on `#stage`, `endPress()` on window `pointerup`/`pointercancel`, `keydown` on the SVG, Reset click.

**End state for chaining:** `gone`.

---

## Notes for a connected sequential prototype

- Each study owns the whole viewport and uses only its own IDs and an IIFE (or class), so they don't collide, but their global CSS (`body`, `:root` variables, `button`) does — embed via `<iframe>` or scope the styles when merging into one page.
- Suggested narrative order: **01 Slime Wand** (load the wand) → **02 Bubble Release** (blow and lift) → **03 Fragile Bubble** (the bubble breaks). Completion signals to hook: 01 `S.shakes` reaching a target, 02 `phase === 'done'`, 03 `done()`.
- Visual languages differ slightly (fonts and greys per study); a shared token set would be the first thing to unify.
- Sizing: 01 and 03 are fluid (max 400 px column); 02 is a fixed 390×844 artboard scaled to fit.

## Files

```
index.html                     launcher linking the three studies
package.json                   optional `npm start` static server
STUDY.md                       this file
01-slime-wand/index.html
02-bubble-release/index.html   standalone port (runs anywhere)
02-bubble-release/source/      original Claude Design canvas files (reference only)
03-fragile-bubble/index.html
```
